# 🦯 Passo Seguro · Navegação Acessível Indoor

Aplicativo web mobile acessível (PWA) desenvolvido para auxiliar pessoas cegas e com baixa visão na locomoção interna passo a passo por voz em estabelecimentos de Recife - PE (**Supermercado Bom Preço**, **Clínica Lucilo Ávila** e **SENAC Recife**).

## ✨ Funcionalidades Principais

- **Tela Inicial de Acesso (Login)**: Identificação por Nome, CPF (com máscara automática) e Senha, ou acesso rápido com **Google**.
- **Minha Conta (Perfil de Acessibilidade)**: Acesso pelo ícone no canto superior direito com informações da conta, estatísticas de rotas, condição visual, auxílio de locomoção (bengala, cão-guia, etc.), contato de emergência e leitura completa por voz.
- **Guiamento Passo a Passo Simplificado**:
  - Escolha do produto/setor e marca.
  - Botão **COMEÇAR** para iniciar a rota e **CONTINUAR INSTRUÇÃO** para avançar trecho a trecho com instruções em passos e metros.
- **Acessibilidade Multimodal (WCAG 2.2 AAA)**:
  - Síntese de voz nativa (Web Speech API) e regiões `aria-live` compatíveis com TalkBack e VoiceOver.
  - Modo de **Alto Contraste (Preto e Amarelo `#FFE500`)** dedicado para baixa visão.
  - Ajuste dinâmico de tamanho da fonte (`Aa`).
  - Feedback sonoro (Web Audio API) e tátil (vibração).
- **Favoritos e Comunidade**: Atalhos rápidos e mural de dicas colaborativas por áudio/texto.

## 📂 Estrutura do Projeto

```text
passoseguro/
├── index.html              # Estrutura principal do aplicativo mobile
├── manifest.json           # Manifesto Web App (PWA)
├── logo-passo-seguro.jpg   # Logotipo oficial Passo Seguro
├── css/
│   └── styles.css          # Estilos mobile, tema oficial e Alto Contraste AAA
└── js/
    ├── data.js             # Mapas, produtos, marcas e estabelecimentos (Recife-PE)
    ├── sensory.js          # Motor de voz, áudio e vibração háptica
    ├── navigation.js       # Algoritmo A* de rotas e conversão em instruções de passos
    └── app.js              # Controlador geral de interface, login, perfil e GPS
```

## 🚀 Como Executar

Basta abrir o arquivo `index.html` em qualquer navegador moderno (Chrome, Edge, Safari ou Firefox) ou hospedar diretamente no **GitHub Pages**.
